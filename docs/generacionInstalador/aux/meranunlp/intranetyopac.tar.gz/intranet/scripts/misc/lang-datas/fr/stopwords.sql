# phpMyAdmin MySQL-Dump
# version 2.2.6-rc1
# http://phpwizard.net/phpMyAdmin/
# http://phpmyadmin.sourceforge.net/ (download page)
#
# Host: localhost
# Generation Time: Nov 22, 2002 at 11:10 AM
# Server version: 3.23.52
# PHP Version: 4.2.3
# Database : `koha_fr`

#
# Dumping data for table `stopwords`
#

INSERT INTO stopwords VALUES ('AU');
INSERT INTO stopwords VALUES ('�A');
INSERT INTO stopwords VALUES ('CAR');
INSERT INTO stopwords VALUES ('CE');
INSERT INTO stopwords VALUES ('CELA');
INSERT INTO stopwords VALUES ('CES');
INSERT INTO stopwords VALUES ('CEUX');
INSERT INTO stopwords VALUES ('CI');
INSERT INTO stopwords VALUES ('DANS');
INSERT INTO stopwords VALUES ('DES');
INSERT INTO stopwords VALUES ('DU');
INSERT INTO stopwords VALUES ('ELLE');
INSERT INTO stopwords VALUES ('ELLES');
INSERT INTO stopwords VALUES ('EN');
INSERT INTO stopwords VALUES ('EST');
INSERT INTO stopwords VALUES ('ET');
INSERT INTO stopwords VALUES ('EU');
INSERT INTO stopwords VALUES ('IL');
INSERT INTO stopwords VALUES ('ILS');
INSERT INTO stopwords VALUES ('JE');
INSERT INTO stopwords VALUES ('LA');
INSERT INTO stopwords VALUES ('LE');
INSERT INTO stopwords VALUES ('LES');
INSERT INTO stopwords VALUES ('LEUR');
INSERT INTO stopwords VALUES ('MA');
INSERT INTO stopwords VALUES ('MAIS');
INSERT INTO stopwords VALUES ('MES');
INSERT INTO stopwords VALUES ('MON');
INSERT INTO stopwords VALUES ('NI');
INSERT INTO stopwords VALUES ('NOTRE');
INSERT INTO stopwords VALUES ('NOUS');
INSERT INTO stopwords VALUES ('OU');
INSERT INTO stopwords VALUES ('PAR');
INSERT INTO stopwords VALUES ('PAS');
INSERT INTO stopwords VALUES ('PEU');
INSERT INTO stopwords VALUES ('PEUT');
INSERT INTO stopwords VALUES ('POUR');
INSERT INTO stopwords VALUES ('QUE');
INSERT INTO stopwords VALUES ('QUI');
INSERT INTO stopwords VALUES ('SA');
INSERT INTO stopwords VALUES ('SES');
INSERT INTO stopwords VALUES ('SI');
INSERT INTO stopwords VALUES ('SIEN');
INSERT INTO stopwords VALUES ('SON');
INSERT INTO stopwords VALUES ('SOUS');
INSERT INTO stopwords VALUES ('SUR');
INSERT INTO stopwords VALUES ('TA');
INSERT INTO stopwords VALUES ('TELS');
INSERT INTO stopwords VALUES ('TES');
INSERT INTO stopwords VALUES ('TON');
INSERT INTO stopwords VALUES ('TU');
INSERT INTO stopwords VALUES ('VOTRE');
INSERT INTO stopwords VALUES ('VOUS');
INSERT INTO stopwords VALUES ('VU');


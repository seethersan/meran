# phpMyAdmin MySQL-Dump
# version 2.4.0
# http://www.phpmyadmin.net/ (download page)
#
# Serveur: localhost
# G�n�r� le : Jeudi 04 D�cembre 2003 � 13:02
# Version du serveur: 4.0.15
# Version de PHP: 4.3.3
# Base de donn�es: `koha_200RC1`

#
# Contenu de la table `stopwords`
#

INSERT INTO stopwords VALUES ('THE');

